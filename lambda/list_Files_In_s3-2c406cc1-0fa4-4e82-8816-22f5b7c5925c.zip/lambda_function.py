import json
import boto3

# Initialize the S3 client
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    
    bucket_name = "sk-athena-testing-1"

    # getting s3 respponse to read objects
    s3_response = s3_client.list_objects_v2(Bucket=bucket_name)

   #lis objects in s3 bucket
    if 'Contents' in s3_response:
        # Print the list of files
        for obj in s3_response['Contents']:
            if not obj['Key'].endswith('/'):
                print(obj['Key'])
    else:
        print(f"No files found in {bucket_name}")
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
